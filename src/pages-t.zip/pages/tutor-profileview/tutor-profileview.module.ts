import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TutorProfileview } from './tutor-profileview';

@NgModule({
  declarations: [
    TutorProfileview,
  ],
  imports: [
    IonicPageModule.forChild(TutorProfileview),
  ],
})
export class TutorProfileviewModule {}
