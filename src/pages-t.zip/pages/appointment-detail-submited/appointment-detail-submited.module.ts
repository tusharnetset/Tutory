import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AppointmentDetailSubmited } from './appointment-detail-submited';

@NgModule({
  declarations: [
    AppointmentDetailSubmited,
  ],
  imports: [
    IonicPageModule.forChild(AppointmentDetailSubmited),
  ],
})
export class AppointmentDetailSubmitedModule {}
