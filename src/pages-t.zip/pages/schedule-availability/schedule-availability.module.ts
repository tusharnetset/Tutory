import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScheduleAvailability } from './schedule-availability';

@NgModule({
  declarations: [
    ScheduleAvailability,
  ],
  imports: [
    IonicPageModule.forChild(ScheduleAvailability),
  ],
})
export class ScheduleAvailabilityModule {}
