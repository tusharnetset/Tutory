import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SettingsStudentPage } from './settings-student';

@NgModule({
  declarations: [
    SettingsStudentPage,
  ],
  imports: [
    IonicPageModule.forChild(SettingsStudentPage),
  ],
})
export class SettingsStudentPageModule {}
