import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermConditonPage } from './term-conditon';

@NgModule({
  declarations: [
    TermConditonPage,
  ],
  imports: [
    IonicPageModule.forChild(TermConditonPage),
  ],
})
export class TermConditonPageModule {}
