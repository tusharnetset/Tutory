import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubCategoryLevel } from './sub-category-level';

@NgModule({
  declarations: [
    SubCategoryLevel,
  ],
  imports: [
    IonicPageModule.forChild(SubCategoryLevel),
  ],
})
export class SubCategoryLevelModule {}
