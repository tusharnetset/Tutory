import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RejectPopup } from './reject-popup';

@NgModule({
  declarations: [
    RejectPopup,
  ],
  imports: [
    IonicPageModule.forChild(RejectPopup),
  ],
})
export class RejectPopupModule {}
