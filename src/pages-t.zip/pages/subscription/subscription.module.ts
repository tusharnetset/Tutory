import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Subscription } from './subscription';

@NgModule({
  declarations: [
    Subscription,
  ],
  imports: [
    IonicPageModule.forChild(Subscription),
  ],
})
export class SubscriptionModule {}
