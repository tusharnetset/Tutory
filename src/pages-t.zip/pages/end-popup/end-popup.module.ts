import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EndPopup } from './end-popup';

@NgModule({
  declarations: [
    EndPopup,
  ],
  imports: [
    IonicPageModule.forChild(EndPopup),
  ],
})
export class EndPopupModule {}
