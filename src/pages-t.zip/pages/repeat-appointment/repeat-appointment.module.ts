import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RepeatAppointmentPage } from './repeat-appointment';

@NgModule({
  declarations: [
    RepeatAppointmentPage,
  ],
  imports: [
    IonicPageModule.forChild(RepeatAppointmentPage),
  ],
})
export class RepeatAppointmentPageModule {}
